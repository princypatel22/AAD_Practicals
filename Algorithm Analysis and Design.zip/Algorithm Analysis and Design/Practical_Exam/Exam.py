import time
import matplotlib.pyplot as plt

def binary_search(arr, target, left, right):
    if left > right:
        return -1
    mid = (left + right) // 2
    if arr[mid] == target:
        return mid
    elif arr[mid] > target:
        return binary_search(arr, target, left, mid - 1)
    else:
        return binary_search(arr, target, mid + 1, right)
    
def linear_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1

lst = [11, 34, 58, 89, 123, 148, 167, 196, 245, 299]
binary_times = []
linear_times = []
target = 89

for n in range(1, len(lst) + 1):
    sublist = lst[:n]
    start_time = time.time()
    binary_search(sublist, target, 0, n - 1)
    binary_times.append(time.time() - start_time)

    start_time = time.time()
    linear_search(sublist, target)
    linear_times.append(time.time() - start_time)

plt.plot(range(1, len(lst) + 1), binary_times, label='Binary Search')
plt.plot(range(1, len(lst) + 1), linear_times, label='Linear Search')
plt.xlabel('Number of elements (n)')
plt.ylabel('Time (seconds)')
plt.title('Comparison of search algorithms')
plt.legend()
plt.show()