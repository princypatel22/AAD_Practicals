class Node:
    def __init__(self, char, freq, left=None, right=None):
        self.char = char
        self.freq = freq
        self.left = left
        self.right = right

def huffman_tree(char_freq):
    nodes = [Node(char, freq) for char, freq in char_freq.items()]
    while len(nodes) > 1:
        nodes = sorted(nodes, key=lambda x: x.freq)
        left = nodes.pop(0)
        right = nodes.pop(0)
        merged = Node(None, left.freq + right.freq, left, right)
        nodes.append(merged)
    return nodes[0]

def huffman_codes(root, current_code="", codes=None):
    if codes is None:
        codes = {}
    if root is None:
        return
    if root.char is not None:
        codes[root.char] = current_code
    huffman_codes(root.left, current_code + "0", codes)
    huffman_codes(root.right, current_code + "1", codes)
    return codes