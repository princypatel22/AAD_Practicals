from flask import Flask, render_template, request
import time
import random
import matplotlib.pyplot as plt
app = Flask(__name__)

def selection_sort(arr):
    swaps=0
    for i in range(len(arr)):
        min_idx = i
        for j in range(i+1, len(arr)):
            if arr[j] < arr[min_idx]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
        swaps+=1
    return swaps

def bubble_sort(arr):
    swaps=0
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                swaps+=1
    return swaps

def generate_random_list(n):
    return [random.randint(0, 1000) for _ in range(n)]



def chart_comparision(n, selection_sort_time, bubble_sort_time):
    plt.bar(['Selection Sort', 'Bubble Sort'], [selection_sort_time, bubble_sort_time])
    plt.xlabel('Algorithm')
    plt.ylabel('Time (seconds)')
    plt.title('Comparison of Sorting Algorithms')
    plt.yticks([selection_sort_time, bubble_sort_time])
    plt.savefig(f'chart_{n}.png')
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        n = int(request.form['n'])
        arr = generate_random_list(n)
        arr1=arr.copy()
        selection_sort_time = selection_sort(arr)
        bubble_sort_time = bubble_sort(arr1)
        chart_comparision(n, selection_sort_time, bubble_sort_time)
        return render_template('result.html', n=n, selection_sort_time=selection_sort_time, bubble_sort_time=bubble_sort_time,chart=f'chart_{n}.png')
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)