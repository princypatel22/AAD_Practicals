from flask import Flask, request, render_template
import networkx as nx

app = Flask(__name__)

def prim_mst(graph):
    mst = nx.minimum_spanning_tree(graph)
    return mst

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        graph_data = request.form['graph_data']
        graph = nx.Graph()
        edges = graph_data.split('\n')
        for edge in edges:
            u, v, weight = edge.split(',')
            graph.add_edge(u, v, weight=int(weight))
        mst = prim_mst(graph)
        return render_template('result.html', mst=mst)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True,port=5001)

    """
A,B,2
A,C,3
B,C,1
B,D,4
C,D,5
"""